// LAB 1 OOP II.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Author: Michai Pryce
// Date: October 6th, 2020
// Student ID: 100668094

#include <iostream>		// for cin, cout
#include <string>		// for output formatting
#include <sstream>		// for stringstream
using namespace std;


class WorkTicketClass
{

public:
	/***************************************************************************
	*	Default and parameterized constructor(s).
	*	If parameters are not specified, set the work ticket number to zero,
	*	the work ticket date to 1/1/2000, and all other attributes to empty
	*	strings.
	***************************************************************************/

	WorkTicketClass() {
		workTicketNumber = 0;
		clientID = "";
		day = 1;
		month = 1;
		year = 2000;
		issuedes = "";
	};
	WorkTicketClass(int theTicketNumber, string theClientID, int theDay, int theMonth, int theYear, string theIssuesdes ) {


	};

	/***************************************************************************
	*	SetWorkTicket()
	*	a mutator method to set all the attributes of the object to the
	*	parameters as long as the parameters are valid. Otherwise throw invalid argurment.
	***************************************************************************/
	
	bool SetWorkTicket(int theTicketNumber, string theClientID, int theDay, int theMonth, int theYear, string theIssuesdes) {
		try
		{
			if (theTicketNumber > 0) {
				if (!theClientID.empty()) {
					if(theDay > 0 && theDay < 32){
						if (theMonth > 0 && theMonth < 13) {
							if (theYear > 1999 && theYear < 3000) {
								if (!theIssuesdes.empty()) {
									SetWorkTicketNumber(theTicketNumber);
									SetClientID(theClientID);
									SetDay(theDay);
									SetMonth(theMonth);
									SetYear(theYear);
									SetIssueDes(theIssuesdes);

								}
								else {
									throw invalid_argument("Invaild entry for issue description! Please enter a min of 1 character!");
								}
							}
							else {
								throw invalid_argument("Invaild entry for year! Please enter appropriate numbers!");
							}
						}
						else {
							throw invalid_argument("Invaild entry for month! Please enter appropriate numbers!");
						}
					}
					else {
						throw invalid_argument("Invaild entry for day! Please enter appropriate numbers!");
					}
				}
				else {
					throw invalid_argument("Invaild entry for the client ID! Please enter a min of 1 character!");
				}
			}
			else {
				throw invalid_argument("Invaild entry for the Ticket Number! Please enter appropriate numbers!");
			}
		}
		catch (const exception& ex)
		{
			cerr << endl << ex.what() << endl; 
			return false;
		}
	};

	//Getter (Accessor for attributes)

	int GetWorkTicketNumber()const{
		 return workTicketNumber;
	}
	string GetClientID()const{
		return clientID;
	}
	int GetDay()const{
		return day;
	}
	int GetMonth()const {
		return month;
	}
	int GetYear()const {
		return year;
	}
	string GetIssueDes()const {
		return issuedes;
	}

	/***************************************************************************
	*	ShowWorkTicket( )
	*	An accessor method to display all the object's attributes neatly in
	*	the console window.
	***************************************************************************/

	string ShowWorkTicket()const {
		std::stringstream output;
		output << "The work ticket : " << workTicketNumber << " ...." << endl << "The ClientID: " << clientID << endl << "The Day: " << day << endl << "The Month: " << month << endl << "The Year: " << year << endl << "The Issue Description: " << issuedes << endl; 
		return output.str(); 
	}

	/***************************************************************************
	*	SetWorkTicket()
	*	a mutator method to set all the attributes of the object to the
	*	parameters as long as the parameters are valid. Otherwise throw invalid argurment.
	***************************************************************************/

	void SetWorkTicketNumber(int theTicketNumber) {
		if (theTicketNumber > 0) {
			workTicketNumber = theTicketNumber;
		}
		else {
			throw invalid_argument("Invaild entry for the Ticket Number! Please enter appropriate numbers!");
		}
	}
	void SetClientID(string theclientID) {
		if (!theclientID.empty()) {
			clientID = theclientID;
		}
		else {
			throw invalid_argument("Invaild entry for the client id! Please enter appropriate information!");
		}
	}
	void SetDay(int theDay) {
		if (theDay > 0 && theDay < 32) {
			day = theDay;
		}
		else {
			throw invalid_argument("Invaild entry for day! Please enter appropriate numbers!");
		}
	}
	void SetMonth(int theMonth) {
		if (theMonth > 0 && theMonth < 13) {
			month = theMonth;
		}
		else {
			throw invalid_argument("Invaild entry for month! Please enter appropriate numbers!");
		}
	}
	void SetYear(int theYear) {
		if (theYear > 1999 && theYear < 3000) {
			year = theYear;
		}
		else {
			throw invalid_argument("Invaild entry for year! Please enter appropriate numbers!");
		}
	}
	void SetIssueDes(string theIssuedes) {
		if (!theIssuedes.empty()) {
			issuedes = theIssuedes;
		}
		else {
			throw invalid_argument("Invaild entry for issue description! Please enter a min of 1 character!");
		}
	}

private:


	/***************************************************************************
	*	Private Attributes.  An object of class WorkTicket has the following
	*		private attributes.
	***************************************************************************/


	int workTicketNumber;
	string clientID; 
	int day;
	int month;
	int year;
	string issuedes;

};




int main()
{
	// Int main Variables
	int theTicketNumber =0;
	string theClientID = "";
	int theDay = 0;
	int theMonth = 0;
	int theYear = 0;
	string theIssuedes = "";
	bool valid = false;

	WorkTicketClass ticketObj[3];

	// Loop to execute user inputs

	for (int i = 0; i < 3; i++) {
		cout << "Enter Workticket Number: " << endl;
		cin >> theTicketNumber;
		cout << "Enter Client ID: " << endl;
		cin >> theClientID;
		cout << "Enter the day :" << endl;
		cin >> theDay;
		cout << "Enter Month: " << endl;
		cin >> theMonth;
		cout << "Enter Year : " << endl;
		cin >> theYear;
		cout << "Enter Issue Description: " << endl;
		cin >> theIssuedes;

		ticketObj[i].SetWorkTicket(theTicketNumber, theClientID, theDay, theMonth, theYear, theIssuedes);
	}

	//for loop to display values

	for (int i = 0; i < 3; i++) {

		cout << ticketObj[i].ShowWorkTicket();
	}




	return 0;
};

